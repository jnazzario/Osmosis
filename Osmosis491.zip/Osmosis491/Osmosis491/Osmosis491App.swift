//
//  Osmosis491App.swift
//  Osmosis491
//
//  Created by Juli Nazzario on 10/17/24.
//

import SwiftUI

@main
struct Osmosis491App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
